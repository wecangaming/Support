﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Support_Admin
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            delete.IsEnabled = false;
            Status.Text = "Status: Bereit";
        }

        private void New_Click(object sender, RoutedEventArgs e)
        {

            Status.Text = "Status: Verbindung wird hergesetllt...";
            ID.Text = "";

            var connect = Properties.Settings.Default.myConnectionString;

            MySqlConnection connection = new MySqlConnection(connect);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM Support WHERE `Claim` = 0 ";
            MySqlDataReader Reader;
            try
            {
                connection.Open();
                Status.Text = "Status: Verbindung hergestellt!";
            }
            catch(Exception ex)
            {
                Status.Text = "Status: Er konnte keine Verbindung hergestellt werden!";
                MessageBox.Show("Es konnte keine Verbindung hergestellt werden!\n\nLösungsvorschläge:\nBitte stelle sicher, dass du mit dem Internet verbunden bist.\nVersuche es gleich nochmal.\nKontaktiere den Support.\n\n Error: " + ex.Message, "Fehler beim verbinden mit der Datenbank", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            Reader = command.ExecuteReader();
            while (Reader.Read())
            {
                string getID = "";
                     getID += Reader.GetString("ID");
                Status.Text = "Status: ID suchen";
                
                string getMail = "";
                getMail += Reader.GetString("Mail");
                Status.Text = "Status: Email wird abgerufen";

                string getBetreff = "";
                getBetreff += Reader.GetString("Betreff");
                Status.Text = "Status: Betreff wird abgerufen";

                string getText = "";
                getText += Reader.GetString("Anliegen");
                Status.Text = "Status: Anliegen wird geladen";

                Status.Text = "Status: Inhalte werden vorbereitet";
                ID.Text = getID;
                Mail.Text = "E-Mail: " + getMail;
                Betreff.Text = "Betreff: " + getBetreff;
                Text.Text = getText;
                Status.Text = "Inhalt geladen";
            }
            connection.Close();
            Status.Text = "Status: Verbindung trennen";
            if (ID.Text == "")
            {
                Status.Text = "Status: Derzeit ist kein Ticket frei!";
                MessageBox.Show("Derzeit ist kein Ticket frei!", "Keine Tickets", MessageBoxButton.OK, MessageBoxImage.None);
            }
            if (ID.Text != "")
            {
                delete.IsEnabled = true;
                Status.Text = "Status: Bereit";
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            delete.IsEnabled = false;
            var connect = Properties.Settings.Default.myConnectionString;
            MySqlConnection connection = new MySqlConnection(connect);
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = "DELETE FROM `Support` WHERE `ID` = ?id";
            command.Parameters.AddWithValue("?id", ID.Text);
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();

            ID.Text = "ID: ";
            Betreff.Text = "Betreff: ";
            Mail.Text = "E-Mail Adresse: ";
            Text.Text = "";
        }
    }
}
