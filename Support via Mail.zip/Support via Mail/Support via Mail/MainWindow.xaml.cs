﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using MySql.Data.MySqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Support_via_Mail
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
        
            InitializeComponent();
        }

        private void Mail_Send_Click(object sender, RoutedEventArgs e)
        {
            
            MailMessage mail = new MailMessage();
            if (Mail_From.Text == "")
            {
                MessageBox.Show("Bitte gebe eine E-Mail Adresse ein!  \nBitte gebe sie an, damit wir bei Rückfragen, Antworten und anderem in Kontakt bleiben können, um so dein Anliegen lösen zu können.", "Keine E-Mail", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            else if (Mail_Text.Text == "")
            {
                MessageBox.Show("Bitte gebe dein Anliegen an!", "Kein Inhalt");
            }
            else
            {
                try
                {
                    mail.From = new MailAddress(Mail_From.Text); //Absender 
                }
                catch
                {
                    MessageBox.Show("Die angegebene E-Mail Adresse ist ungültig! \nBitte gebe sie an, damit wir bei Rückfragen, Antworten und anderem in Kontakt bleiben können, um so dein Anliegen lösen zu können.", "Fehlerhafte E-Mail Adresse", MessageBoxButton.OK, MessageBoxImage.Stop);
                    goto end_email;
                }
                mail.To.Add(Properties.Settings.Default.Mail_To); //Empfänger 
                mail.Subject = "Support Anfrage: " + Mail_Betreff.Text;
                mail.Body = "Anfrage vom: " + DateTime.Now + "\n\n\nBetreff: " + Mail_Betreff.Text +"\n\n\nAnliegen des Nutzers:\n\n" + Mail_Text.Text + "\n\n\n Kontakt zum Nutzer: " + Mail_From.Text;
                mail.IsBodyHtml = false; //Nur wenn Body HTML Quellcode ist  

                SmtpClient client = new SmtpClient("domvi.de", 25); //SMTP Server von Hotmail und Outlook. 

                try
                {
                    client.Credentials = new System.Net.NetworkCredential("dnick@domvi.de", "");//Anmeldedaten für den SMTP Server 

                    client.EnableSsl = false; //Die meisten Anbieter verlangen eine SSL-Verschlüsselung 

                    client.Send(mail); //Senden 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Fehler beim Senden der Supportanfrage!\n\n" + ex.Message, "Fehler beim senden!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                MessageBox.Show("Deine Anfrage wurde gesendet!", "Anfrage gesendet!", MessageBoxButton.OK, MessageBoxImage.None);
                string myConnectionString = "SERVER=admin.domvi.de;" +
                            "DATABASE=CSharp;" +
                            "UID=CSharp;" +
                            "PASSWORD=Test1;";
                MySqlConnection connection = new MySqlConnection(myConnectionString);
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "INSERT INTO `Support`(`Mail`, `Betreff`, `Anliegen`) VALUES (?Mail_From,?Mail_Betreff,?Mail_Text)";
                command.Parameters.AddWithValue("?Mail_From", Mail_From.Text);
                command.Parameters.AddWithValue("?Mail_Betreff", Mail_Betreff.Text);
                command.Parameters.AddWithValue("?Mail_Text", Mail_Text.Text);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            end_email:
                ;
            }
        }
    }
}
